export type CategoryType = 'all' | 'football' | 'cricket' | 'tracksuits' | 'custom';

export interface Product {
  id: string;
  name: string;
  category: 'football' | 'cricket' | 'tracksuits' | 'custom';
  categoryLabel: string;
  description: string;
  features: string[];
  image: string;
  isSample: boolean;
  availableSizes: string[];
  recommendedSport: 'Football' | 'Cricket' | 'Training / Fitness' | 'Multi-Sport';
  fitType: 'Athletic Fit' | 'Relaxed Fit' | 'Regular Fit';
}

export interface CustomKitInquiry {
  sport: 'Football' | 'Cricket';
  orderType: 'Individual' | 'Team';
  customerName: string;
  contactNumber: string;
  teamName: string;
  quantity: number;
  preferredColors: string;
  playerNamesAndNumbers: string;
  sizesBreakdown: string;
  requestedDate: string;
  additionalNotes: string;
  referenceImageName?: string;
}

export interface ValidationErrors {
  customerName?: string;
  contactNumber?: string;
  quantity?: string;
  preferredColors?: string;
}
