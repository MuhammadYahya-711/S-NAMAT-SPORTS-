import React from 'react';
import { Phone, MessageSquare, MapPin } from 'lucide-react';
import { DISPLAY_PHONE, WHATSAPP_PHONE_NUMBER, DISPLAY_ADDRESS, MAPS_URL } from '../utils/inquiry';

interface FooterProps {
  onNavigate: (tab: string) => void;
  onCustomKitClick: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onCustomKitClick }) => {
  return (
    <footer className="bg-[#080A0D] border-t border-[#151A21] text-[#A6AFBD] text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="font-display text-xl font-black tracking-tight text-white">
              S NAIMAT <span className="text-[#1769FF]">SPORTS</span>
            </div>
            <p className="text-xs text-[#8E9AA8] leading-relaxed">
              Sportswear, football shirts and kits, cricket kits, tracksuits, and bespoke custom teamwear pre-orders based in Quetta, Pakistan.
            </p>
            <div className="pt-2">
              <span className="text-[11px] font-semibold text-[#C6F235] uppercase tracking-wider">
                Pre-Order Inquiries Open
              </span>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-wider text-white mb-4">
              Explore Collections
            </h4>
            <ul className="space-y-2.5">
              <li>
                <button
                  onClick={() => onNavigate('shop')}
                  className="hover:text-white transition-colors text-left"
                >
                  All Products
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('football')}
                  className="hover:text-white transition-colors text-left"
                >
                  Football Kits
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('cricket')}
                  className="hover:text-white transition-colors text-left"
                >
                  Cricket Kits
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('tracksuits')}
                  className="hover:text-white transition-colors text-left"
                >
                  Tracksuits
                </button>
              </li>
              <li>
                <button
                  onClick={onCustomKitClick}
                  className="text-[#C6F235] hover:underline transition-colors text-left font-medium"
                >
                  Custom Kit Pre-Order Builder
                </button>
              </li>
            </ul>
          </div>

          {/* Store Location */}
          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-wider text-white mb-4">
              Quetta Showroom
            </h4>
            <div className="space-y-3">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#1769FF] shrink-0 mt-0.5" />
                <span className="text-xs leading-relaxed">
                  {DISPLAY_ADDRESS}
                </span>
              </div>
              <div>
                <a
                  href={MAPS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[#1769FF] hover:underline font-semibold"
                >
                  <span>Open Directions on Google Maps</span>
                </a>
              </div>
            </div>
          </div>

          {/* Contact Details */}
          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-wider text-white mb-4">
              Direct Contact
            </h4>
            <div className="space-y-3">
              <div>
                <div className="text-[10px] text-[#717F91] uppercase tracking-wider">Call Us:</div>
                <a
                  href={`tel:+${WHATSAPP_PHONE_NUMBER}`}
                  className="text-white hover:text-[#1769FF] font-medium flex items-center gap-2 mt-0.5"
                >
                  <Phone className="w-3.5 h-3.5 text-[#1769FF]" />
                  <span>{DISPLAY_PHONE}</span>
                </a>
              </div>

              <div>
                <div className="text-[10px] text-[#717F91] uppercase tracking-wider">WhatsApp Pre-Orders:</div>
                <a
                  href={`https://wa.me/${WHATSAPP_PHONE_NUMBER}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#C6F235] hover:underline font-medium flex items-center gap-2 mt-0.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>+{WHATSAPP_PHONE_NUMBER}</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-[#151A21] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#717F91]">
          <div>
            &copy; {new Date().getFullYear()} S NAIMAT SPORTS. All rights reserved.
          </div>
          <div className="text-center sm:text-right">
            Sports apparel catalog and pre-order inquiries · Quetta, Pakistan
          </div>
        </div>
      </div>
    </footer>
  );
};
