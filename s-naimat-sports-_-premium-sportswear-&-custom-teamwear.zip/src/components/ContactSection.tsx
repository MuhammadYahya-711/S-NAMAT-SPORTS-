import React, { useState } from 'react';
import { Phone, MessageSquare, MapPin, Send, ExternalLink, ArrowRight } from 'lucide-react';
import { DISPLAY_PHONE, WHATSAPP_PHONE_NUMBER, DISPLAY_ADDRESS, MAPS_URL, createWhatsAppUrl } from '../utils/inquiry';

export const ContactSection: React.FC = () => {
  const [quickMsg, setQuickMsg] = useState('');

  const handleSendQuickMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const text = quickMsg.trim() || 'Hello S NAIMAT SPORTS! I would like to inquire about sportswear products.';
    const url = createWhatsAppUrl(WHATSAPP_PHONE_NUMBER, text);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contact" className="py-20 bg-[#0B0D10] border-t border-[#151A21]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#C6F235] mb-2">
            <span>GET IN TOUCH WITH US</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl font-black text-white tracking-tight mb-4">
            VISIT OUR SHOWROOM OR INQUIRE ON WHATSAPP
          </h2>
          <p className="text-sm sm:text-base text-[#A6AFBD] leading-relaxed">
            Have questions about football kits, cricket kits, tracksuits, or custom teamwear pre-orders? Contact S NAIMAT SPORTS directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Contact Methods (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            {/* Call Action */}
            <a
              href={`tel:+${WHATSAPP_PHONE_NUMBER}`}
              className="group p-5 bg-[#151A21] hover:bg-[#1A222D] border border-[#222B38] hover:border-[#1769FF]/50 rounded-xl flex items-center justify-between transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF] group-hover:bg-[#1769FF] group-hover:text-white transition-colors">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#717F91]">
                    Direct Phone Call
                  </div>
                  <div className="font-display text-base sm:text-lg font-bold text-white group-hover:text-[#1769FF] transition-colors">
                    {DISPLAY_PHONE}
                  </div>
                  <div className="text-xs text-[#A6AFBD]">
                    Tap to call from mobile
                  </div>
                </div>
              </div>
              <ArrowRight className="w-5 h-5 text-[#8E9AA8] group-hover:text-white group-hover:translate-x-1 transition-all" />
            </a>

            {/* WhatsApp Action */}
            <a
              href={`https://wa.me/${WHATSAPP_PHONE_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-5 bg-[#151A21] hover:bg-[#1A222D] border border-[#222B38] hover:border-[#C6F235]/50 rounded-xl flex items-center justify-between transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#C6F235]/10 border border-[#C6F235]/30 flex items-center justify-center text-[#C6F235] group-hover:bg-[#C6F235] group-hover:text-[#0B0D10] transition-colors">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#717F91]">
                    Official WhatsApp
                  </div>
                  <div className="font-display text-base sm:text-lg font-bold text-white group-hover:text-[#C6F235] transition-colors">
                    +{WHATSAPP_PHONE_NUMBER}
                  </div>
                  <div className="text-xs text-[#A6AFBD]">
                    Fast inquiries for custom kits and product availability
                  </div>
                </div>
              </div>
              <ExternalLink className="w-5 h-5 text-[#8E9AA8] group-hover:text-white transition-all" />
            </a>

            {/* Location / Google Maps */}
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group p-5 bg-[#151A21] hover:bg-[#1A222D] border border-[#222B38] hover:border-[#1769FF]/50 rounded-xl flex items-center justify-between transition-all"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF] group-hover:bg-[#1769FF] group-hover:text-white transition-colors">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-[#717F91]">
                    Store Address &amp; Navigation
                  </div>
                  <div className="font-display text-base sm:text-lg font-bold text-white group-hover:text-[#1769FF] transition-colors">
                    {DISPLAY_ADDRESS}
                  </div>
                  <div className="text-xs text-[#A6AFBD]">
                    Open in Google Maps for live directions
                  </div>
                </div>
              </div>
              <ExternalLink className="w-5 h-5 text-[#8E9AA8] group-hover:text-white transition-all" />
            </a>
          </div>

          {/* Quick Message Box (5 cols) */}
          <div className="lg:col-span-5 bg-[#12161D] border border-[#1E2633] rounded-2xl p-6 sm:p-7 shadow-xl">
            <h3 className="font-display text-base font-bold text-white mb-2">
              Send a Quick Inquiry via WhatsApp
            </h3>
            <p className="text-xs text-[#A6AFBD] leading-relaxed mb-4">
              Type your question below and hit send. It will immediately open WhatsApp pre-addressed to S NAIMAT SPORTS.
            </p>

            <form onSubmit={handleSendQuickMessage} className="space-y-4">
              <div>
                <textarea
                  rows={4}
                  value={quickMsg}
                  onChange={(e) => setQuickMsg(e.target.value)}
                  placeholder="e.g. Assalam-o-Alaikum, I want to check availability for football kits in size L, and inquire about prices for 15 cricket kits..."
                  className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 bg-[#C6F235] hover:bg-[#b5e028] text-[#0B0D10] text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Start WhatsApp Conversation</span>
              </button>
            </form>

            <div className="mt-4 pt-4 border-t border-[#1E2633] text-[11px] text-[#717F91] text-center">
              Direct connection with our Quetta store team.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
