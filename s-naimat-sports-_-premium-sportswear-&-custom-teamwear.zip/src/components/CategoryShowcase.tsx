import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { CATEGORIES } from '../data/products';

interface CategoryShowcaseProps {
  onSelectCategory: (categoryId: string) => void;
}

export const CategoryShowcase: React.FC<CategoryShowcaseProps> = ({ onSelectCategory }) => {
  return (
    <section className="py-16 sm:py-20 bg-[#0B0D10] border-t border-[#151A21]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-[#1769FF] mb-2">
              APPAREL &amp; GEAR CATEGORIES
            </div>
            <h2 className="font-display text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              BUILT FOR EVERY MATCH
            </h2>
          </div>
          <p className="text-sm text-[#A6AFBD] max-w-md">
            From premier football kits and tournament cricket gear to athletic tracksuits and full bespoke teamwear pre-orders.
          </p>
        </div>

        {/* 4 Category Showcase Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className="group relative h-96 rounded-xl overflow-hidden text-left bg-[#151A21] border border-[#1E2633] hover:border-[#1769FF]/50 transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF] flex flex-col justify-end p-6"
            >
              {/* Category Image with Zoom on Hover */}
              <img
                src={cat.image}
                alt={cat.title}
                referrerPolicy="no-referrer"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  const fallback = `/images/${cat.id}.jpg`;
                  if (target.src !== fallback) {
                    target.src = fallback;
                  }
                }}
                className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out opacity-75"
              />

              {/* Contrast Scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0D10] via-[#0B0D10]/60 to-transparent" />

              {/* Tag / Category Badge */}
              <div className="relative z-10 mb-auto">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#C6F235] bg-[#0B0D10]/80 backdrop-blur-sm px-2.5 py-1 rounded">
                  {cat.badgeText}
                </span>
              </div>

              {/* Content Block */}
              <div className="relative z-10">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <h3 className="font-display text-xl font-bold text-white group-hover:text-[#1769FF] transition-colors">
                    {cat.title}
                  </h3>
                  <div className="w-8 h-8 rounded-full bg-[#151A21]/90 border border-[#2B3545] flex items-center justify-center text-white group-hover:bg-[#1769FF] group-hover:border-[#1769FF] transition-colors shrink-0">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>
                <p className="text-xs text-[#A6AFBD] line-clamp-2 leading-relaxed">
                  {cat.tagline}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
