import React from 'react';
import { ArrowRight, ShieldCheck, Shirt, MapPin } from 'lucide-react';
import { HERO_IMAGE } from '../data/products';

interface HeroProps {
  onShopClick: () => void;
  onCustomKitClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onShopClick, onCustomKitClick }) => {
  return (
    <section className="relative min-h-[580px] lg:min-h-[660px] flex items-center justify-center overflow-hidden bg-[#0B0D10]">
      {/* Background Hero Image with Measured Scrim */}
      <div className="absolute inset-0 z-0 bg-[#0B0D10]">
        <img
          src={HERO_IMAGE}
          alt="Athlete wearing athletic performance kit in athletic studio"
          referrerPolicy="no-referrer"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            if (target.src !== '/images/hero.jpg') {
              target.src = '/images/hero.jpg';
            }
          }}
          className="w-full h-full object-cover object-center lg:object-right opacity-45 scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Multilayer gradient scrim for 4.5:1 legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B0D10] via-[#0B0D10]/85 to-[#0B0D10]/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0D10] via-transparent to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 w-full">
        <div className="max-w-2xl">
          {/* Quiet clean unboxed kicker */}
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#C6F235] mb-4">
            <span>S NAIMAT SPORTS</span>
            <span aria-hidden="true" className="text-[#3A4556]">·</span>
            <span>QUETTA, PAKISTAN</span>
            <span aria-hidden="true" className="text-[#3A4556]">·</span>
            <span>ESTABLISHED SPORTSWEAR</span>
          </div>

          {/* Powerful Headline */}
          <h1 className="font-display text-4xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight leading-[1.05] mb-6 text-balance">
            GEAR UP.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-[#1769FF]">
              PLAY BOLD.
            </span>
          </h1>

          {/* Supporting Copy */}
          <p className="text-base sm:text-lg text-[#A6AFBD] leading-relaxed mb-8 max-w-xl">
            Specializing in high-performance football shirts &amp; kits, tournament cricket kits, and athletic tracksuits. Pre-order custom teamwear designed to your exact club colors, crests, and player rosters.
          </p>

          {/* Two CTAs */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 mb-10">
            <button
              onClick={onShopClick}
              className="px-6 py-3.5 bg-[#1769FF] hover:bg-[#0f54d1] active:scale-[0.98] text-white text-sm font-bold uppercase tracking-wider rounded transition-all shadow-lg shadow-[#1769FF]/20 flex items-center justify-center gap-2 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
            >
              <span>SHOP COLLECTION</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onCustomKitClick}
              className="px-6 py-3.5 bg-[#151A21] hover:bg-[#1E2530] border border-[#2D3847] active:scale-[0.98] text-white hover:text-[#C6F235] text-sm font-bold uppercase tracking-wider rounded transition-all flex items-center justify-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6F235]"
            >
              <Shirt className="w-4 h-4 text-[#C6F235]" />
              <span>CUSTOMIZE YOUR KIT</span>
            </button>
          </div>

          {/* Clean unboxed proof points */}
          <div className="pt-6 border-t border-[#1F2733] flex flex-wrap items-center gap-y-3 gap-x-6 text-xs text-[#8E9AA8]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#1769FF]" />
              <span>Durable Sports Fabrics</span>
            </div>
            <span aria-hidden="true" className="text-[#3A4556] hidden sm:inline">·</span>
            <div className="flex items-center gap-2">
              <Shirt className="w-4 h-4 text-[#C6F235]" />
              <span>Custom Team Sublimation</span>
            </div>
            <span aria-hidden="true" className="text-[#3A4556] hidden sm:inline">·</span>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#1769FF]" />
              <span>Gurdat Singh Rd, Quetta</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
