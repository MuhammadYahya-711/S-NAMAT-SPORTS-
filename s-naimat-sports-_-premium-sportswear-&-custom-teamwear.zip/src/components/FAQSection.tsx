import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { DISPLAY_PHONE, WHATSAPP_PHONE_NUMBER, DISPLAY_ADDRESS } from '../utils/inquiry';

export const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What sportswear products does S NAIMAT SPORTS offer?',
      a: 'We specialize in football shirts and complete kits, tournament cricket kits, and athletic performance tracksuits. We also offer bespoke custom football and cricket kits through pre-order inquiries.'
    },
    {
      q: 'How does the custom kit pre-order inquiry process work?',
      a: 'You can use our online custom kit inquiry form or message us directly on WhatsApp (+92 313 8873304). Provide your chosen sport (football or cricket), squad quantity, preferred colors, and roster details. Our team in Quetta will connect with you to review design mockups, fabric choices, and quotes.'
    },
    {
      q: 'Where is your showroom located in Quetta?',
      a: `Our physical store is located at ${DISPLAY_ADDRESS}. You can visit us in person to review fabric quality, examine samples, and discuss custom team kit designs.`
    },
    {
      q: 'Can I order a single kit or only bulk team orders?',
      a: 'We accommodate both individual players looking for single kits or tracksuits and full squads/clubs ordering 5, 12, 20 or more customized team kits.'
    },
    {
      q: 'How do I check pricing and current stock?',
      a: `Because prices and stock vary based on customizations, fabric specifications, and seasonal shipments, we provide direct quotes via WhatsApp (+92 313 8873304) or phone call (${DISPLAY_PHONE}). This guarantees you receive accurate, up-to-date pricing.`
    }
  ];

  return (
    <section id="faq" className="py-20 bg-[#0E1217] border-t border-[#18202A]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="text-xs font-bold uppercase tracking-widest text-[#1769FF] mb-2">
            FREQUENTLY ASKED QUESTIONS
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
            FREQUENT QUESTIONS &amp; PRE-ORDER DETAILS
          </h2>
          <p className="text-sm text-[#A6AFBD] max-w-xl mx-auto">
            Clear, straightforward information about our sportswear catalog, pre-order inquiries, and store location in Quetta.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={faq.q}
                className="bg-[#151A21] border border-[#222B38] rounded-xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenIndex(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
                >
                  <span className="font-display text-sm sm:text-base font-bold text-white">
                    {faq.q}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#C6F235] shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-[#A6AFBD] leading-relaxed border-t border-[#1F2733]/60">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
