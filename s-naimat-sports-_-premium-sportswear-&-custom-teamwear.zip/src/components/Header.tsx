import React, { useState } from 'react';
import { Menu, X, Phone, MessageSquare, MapPin } from 'lucide-react';
import { WHATSAPP_PHONE_NUMBER, DISPLAY_PHONE, MAPS_URL } from '../utils/inquiry';

interface HeaderProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  onCustomKitClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onNavigate,
  onCustomKitClick,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'football', label: 'Football Kits' },
    { id: 'cricket', label: 'Cricket Kits' },
    { id: 'tracksuits', label: 'Tracksuits' },
    { id: 'custom', label: 'Custom Kits' },
    { id: 'about', label: 'About' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0B0D10]/95 backdrop-blur-md border-b border-[#1A222D]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center text-left group shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
        >
          <div className="flex flex-col">
            <span className="font-display text-xl sm:text-2xl font-black tracking-tight text-white group-hover:text-[#1769FF] transition-colors">
              S NAIMAT <span className="text-[#1769FF]">SPORTS</span>
            </span>
            <span className="text-[10px] uppercase tracking-widest text-[#A6AFBD] font-medium">
              Quetta · Sportswear &amp; Teamwear
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-[#A6AFBD]" aria-label="Main Navigation">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`whitespace-nowrap transition-colors relative py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF] rounded ${
                  isActive ? 'text-white font-semibold' : 'hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#C6F235] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1 Primary Action (Desktop) */}
        <div className="hidden sm:flex items-center gap-3 shrink-0">
          <button
            onClick={() => {
              onCustomKitClick();
              setMobileMenuOpen(false);
            }}
            className="px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-[#0B0D10] bg-[#C6F235] hover:bg-[#b5e028] active:scale-[0.98] rounded transition-all shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6F235] whitespace-nowrap"
          >
            Customize Kit
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={onCustomKitClick}
            className="px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-[#0B0D10] bg-[#C6F235] rounded sm:hidden"
          >
            Inquire
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
            className="p-2 text-[#A6AFBD] hover:text-white hover:bg-[#151A21] rounded-lg transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0B0D10] border-b border-[#1A222D] px-4 pt-3 pb-6 animate-in slide-in-from-top duration-150">
          <div className="space-y-1 mb-4">
            {navLinks.map((link) => {
              const isActive = activeTab === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavClick(link.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                    isActive
                      ? 'bg-[#151A21] text-[#C6F235] font-semibold border-l-2 border-[#C6F235]'
                      : 'text-[#A6AFBD] hover:bg-[#151A21]/60 hover:text-white'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-[#1A222D] space-y-3">
            <button
              onClick={() => {
                onCustomKitClick();
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 px-4 text-center font-bold text-xs uppercase tracking-wider text-[#0B0D10] bg-[#C6F235] hover:bg-[#b5e028] rounded transition-colors"
            >
              Start Custom Kit Pre-Order
            </button>

            <div className="grid grid-cols-2 gap-2 text-xs text-[#A6AFBD]">
              <a
                href={`tel:${DISPLAY_PHONE}`}
                className="flex items-center justify-center gap-1.5 p-2.5 bg-[#151A21] rounded hover:text-white transition-colors"
              >
                <Phone className="w-3.5 h-3.5 text-[#1769FF]" />
                <span>Call Store</span>
              </a>
              <a
                href={`https://wa.me/${WHATSAPP_PHONE_NUMBER}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 p-2.5 bg-[#151A21] rounded hover:text-white transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#C6F235]" />
                <span>WhatsApp</span>
              </a>
            </div>

            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 p-2.5 text-xs text-[#A6AFBD] bg-[#151A21] rounded hover:text-white transition-colors"
            >
              <MapPin className="w-3.5 h-3.5 text-[#1769FF]" />
              <span>Gurdat Singh Rd, Quetta</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
