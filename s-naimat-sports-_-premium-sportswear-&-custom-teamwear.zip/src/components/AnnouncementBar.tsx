import React from 'react';
import { ArrowRight, MessageSquare } from 'lucide-react';
import { WHATSAPP_PHONE_NUMBER, createWhatsAppUrl } from '../utils/inquiry';

interface AnnouncementBarProps {
  onCustomKitClick: () => void;
}

export const AnnouncementBar: React.FC<AnnouncementBarProps> = ({ onCustomKitClick }) => {
  const quickWhatsAppUrl = createWhatsAppUrl(
    WHATSAPP_PHONE_NUMBER,
    'Hello S NAIMAT SPORTS! I would like to inquire about sportswear and custom kit pre-orders.'
  );

  return (
    <div className="bg-[#151A21] border-b border-[#222B38] text-xs text-[#A6AFBD] py-2 px-4">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#C6F235]" aria-hidden="true"></span>
          <span className="font-medium text-white">Pre-Order Inquiries Open:</span>
          <span>Custom Football &amp; Cricket Kits available for clubs &amp; teams</span>
        </div>
        
        <div className="flex items-center gap-4 text-xs">
          <button 
            onClick={onCustomKitClick}
            className="text-[#C6F235] hover:underline font-medium flex items-center gap-1 transition-colors"
          >
            Start Kit Pre-Order <ArrowRight className="w-3 h-3" />
          </button>
          <span className="text-[#303B4C]" aria-hidden="true">|</span>
          <a
            href={quickWhatsAppUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#A6AFBD] hover:text-white flex items-center gap-1 transition-colors"
          >
            <MessageSquare className="w-3 h-3 text-[#1769FF]" />
            <span>WhatsApp: 03138873304</span>
          </a>
        </div>
      </div>
    </div>
  );
};
