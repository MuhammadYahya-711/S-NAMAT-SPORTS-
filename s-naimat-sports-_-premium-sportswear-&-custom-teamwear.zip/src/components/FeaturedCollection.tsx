import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, Shirt, Sparkles } from 'lucide-react';
import { Product, CategoryType } from '../types';
import { ProductCard } from './ProductCard';

interface FeaturedCollectionProps {
  products: Product[];
  selectedCategory: CategoryType;
  onCategoryChange: (category: CategoryType) => void;
  onQuickView: (product: Product) => void;
  onCustomKitClick: () => void;
}

export const FeaturedCollection: React.FC<FeaturedCollectionProps> = ({
  products,
  selectedCategory,
  onCategoryChange,
  onQuickView,
  onCustomKitClick,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'default' | 'name-asc' | 'name-desc'>('default');

  const categories: { id: CategoryType; label: string }[] = [
    { id: 'all', label: 'All Products' },
    { id: 'football', label: 'Football Kits' },
    { id: 'cricket', label: 'Cricket Kits' },
    { id: 'tracksuits', label: 'Tracksuits' },
    { id: 'custom', label: 'Custom Teamwear' },
  ];

  const filteredProducts = useMemo(() => {
    return products
      .filter((product) => {
        const matchesCategory =
          selectedCategory === 'all' || product.category === selectedCategory;
        const matchesSearch =
          searchQuery.trim() === '' ||
          product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          product.recommendedSport.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
      })
      .sort((a, b) => {
        if (sortBy === 'name-asc') return a.name.localeCompare(b.name);
        if (sortBy === 'name-desc') return b.name.localeCompare(a.name);
        return 0;
      });
  }, [products, selectedCategory, searchQuery, sortBy]);

  return (
    <section id="collection" className="py-16 sm:py-24 bg-[#0B0D10] border-t border-[#151A21]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header & Title */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-[#1769FF] mb-2">
              FEATURED SPORTSWEAR CATALOG
            </div>
            <h2 className="font-display text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              SPORTSWEAR &amp; APPAREL
            </h2>
          </div>
          
          {/* Transparent sample catalog note */}
          <div className="bg-[#151A21] border border-[#242D3B] px-4 py-2.5 rounded-lg text-xs text-[#A6AFBD] max-w-md">
            <span className="font-semibold text-white">Showroom Catalog Notice:</span> Items shown are sample showcase designs available for retail availability confirmation and custom club pre-orders via WhatsApp.
          </div>
        </div>

        {/* Filter Controls & Search Bar */}
        <div className="bg-[#12161D] border border-[#1E2633] rounded-xl p-4 mb-8">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4">
            {/* Category Segmented Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0 scrollbar-none">
              {categories.map((cat) => {
                const isActive = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => onCategoryChange(cat.id)}
                    className={`px-3.5 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF] ${
                      isActive
                        ? 'bg-[#1769FF] text-white shadow-sm'
                        : 'bg-[#151A21] text-[#A6AFBD] hover:text-white hover:bg-[#1A222D]'
                    }`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>

            {/* Search and Sort */}
            <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
              <div className="relative flex-1 sm:w-64">
                <Search className="w-4 h-4 text-[#8E9AA8] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search kits, tracksuits..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
                />
              </div>

              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#8E9AA8]" />
                <select
                  aria-label="Sort products"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-[#151A21] border border-[#242D3B] rounded-lg px-2.5 py-2 text-xs text-[#A6AFBD] focus:outline-none focus:border-[#1769FF]"
                >
                  <option value="default">Default Order</option>
                  <option value="name-asc">Name (A-Z)</option>
                  <option value="name-desc">Name (Z-A)</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Product Count & Active Category Indicator */}
        <div className="flex items-center justify-between text-xs text-[#8E9AA8] mb-6">
          <div>
            Showing <span className="font-semibold text-white">{filteredProducts.length}</span> sports apparel items
          </div>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-[#C6F235] hover:underline"
            >
              Clear search &quot;{searchQuery}&quot;
            </button>
          )}
        </div>

        {/* Product Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onQuickView={onQuickView}
              />
            ))}
          </div>
        ) : (
          <div className="bg-[#151A21] border border-[#1E2633] rounded-xl p-12 text-center">
            <Shirt className="w-10 h-10 text-[#5D6B7D] mx-auto mb-3" />
            <h3 className="font-display text-lg font-bold text-white mb-1">
              No matching sports items found
            </h3>
            <p className="text-xs text-[#A6AFBD] mb-4 max-w-sm mx-auto">
              We couldn&apos;t find any products matching your search criteria. Try clearing the filter or contact us for custom team inquiries.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                onCategoryChange('all');
              }}
              className="px-4 py-2 bg-[#1769FF] text-white text-xs font-semibold rounded hover:bg-[#0f54d1] transition-colors"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Custom Teamwear Banner Strip */}
        <div className="mt-12 bg-gradient-to-r from-[#151A21] via-[#1A222D] to-[#151A21] border border-[#252F3E] rounded-xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF] shrink-0">
              <Sparkles className="w-6 h-6 text-[#C6F235]" />
            </div>
            <div>
              <h3 className="font-display text-lg sm:text-xl font-bold text-white mb-1">
                Need Custom Football or Cricket Kits for Your Entire Squad?
              </h3>
              <p className="text-xs sm:text-sm text-[#A6AFBD] max-w-xl">
                We manufacture bespoke sublimated jerseys with custom crests, sponsor logos, player names, and squad numbers through pre-order inquiries.
              </p>
            </div>
          </div>
          <button
            onClick={onCustomKitClick}
            className="px-6 py-3 bg-[#C6F235] hover:bg-[#b5e028] text-[#0B0D10] text-xs font-bold uppercase tracking-wider rounded transition-all whitespace-nowrap shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6F235] shrink-0"
          >
            Start Team Inquiry
          </button>
        </div>
      </div>
    </section>
  );
};
