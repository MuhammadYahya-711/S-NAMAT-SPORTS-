import React from 'react';
import { MapPin, Phone, MessageSquare, Shirt, Award } from 'lucide-react';
import { DISPLAY_PHONE, WHATSAPP_PHONE_NUMBER, DISPLAY_ADDRESS, MAPS_URL } from '../utils/inquiry';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-[#0E1217] border-t border-[#18202A]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#1769FF] mb-2">
            <span>ABOUT S NAIMAT SPORTS</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl font-black text-white tracking-tight mb-4">
            DEDICATED TO ATHLETIC EXCELLENCE IN QUETTA
          </h2>
          <p className="text-sm sm:text-base text-[#A6AFBD] leading-relaxed">
            S NAIMAT SPORTS is a premier sportswear and sports equipment/apparel destination based on Gurdat Singh Road in Quetta, Pakistan.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1: Core Offerings */}
          <div className="bg-[#151A21] border border-[#222B38] rounded-xl p-6 space-y-4">
            <div className="w-10 h-10 rounded-lg bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF]">
              <Shirt className="w-5 h-5 text-[#C6F235]" />
            </div>
            <h3 className="font-display text-lg font-bold text-white">
              Specialized Sportswear
            </h3>
            <p className="text-xs text-[#A6AFBD] leading-relaxed">
              We specialize in football shirts and kits, cricket kits, tracksuits, and athletic apparel designed for training and competitive match performance.
            </p>
          </div>

          {/* Card 2: Custom Teamwear Pre-Orders */}
          <div className="bg-[#151A21] border border-[#222B38] rounded-xl p-6 space-y-4">
            <div className="w-10 h-10 rounded-lg bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF]">
              <Award className="w-5 h-5 text-[#1769FF]" />
            </div>
            <h3 className="font-display text-lg font-bold text-white">
              Custom Kit Pre-Orders
            </h3>
            <p className="text-xs text-[#A6AFBD] leading-relaxed">
              Custom football and cricket kits are available through pre-order inquiries, enabling teams and clubs to customize colors, player names, numbers, and squad sizes.
            </p>
          </div>

          {/* Card 3: Quetta Location & Direct Communication */}
          <div className="bg-[#151A21] border border-[#222B38] rounded-xl p-6 space-y-4">
            <div className="w-10 h-10 rounded-lg bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF]">
              <MapPin className="w-5 h-5 text-[#C6F235]" />
            </div>
            <h3 className="font-display text-lg font-bold text-white">
              Showroom Location
            </h3>
            <p className="text-xs text-[#A6AFBD] leading-relaxed mb-2">
              Located at 52Q7+CC9, Gurdat Singh Rd, Quetta, Pakistan. We welcome players and team managers for direct inquiries and sizing consultations.
            </p>
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs text-[#1769FF] hover:underline font-semibold"
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>Get Directions on Google Maps</span>
            </a>
          </div>
        </div>

        {/* Fact Sheet Banner */}
        <div className="mt-8 bg-[#12161D] border border-[#1E2633] rounded-xl p-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="text-xs text-[#8E9AA8]">
              <span className="text-white font-bold">Business Name:</span> S NAIMAT SPORTS
            </div>
            <span aria-hidden="true" className="text-[#303B4C]">·</span>
            <div className="text-xs text-[#8E9AA8]">
              <span className="text-white font-bold">City:</span> Quetta, Pakistan
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <a
              href={`tel:${DISPLAY_PHONE}`}
              className="flex items-center gap-1.5 text-[#A6AFBD] hover:text-white transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-[#1769FF]" />
              <span>{DISPLAY_PHONE}</span>
            </a>
            <a
              href={`https://wa.me/${WHATSAPP_PHONE_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-[#C6F235] hover:underline transition-colors"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>WhatsApp: +{WHATSAPP_PHONE_NUMBER}</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
