import React, { useState } from 'react';
import {
  Shirt,
  Send,
  Copy,
  Check,
  AlertCircle,
  Upload,
  Calendar,
  Sparkles,
  Info
} from 'lucide-react';
import { CustomKitInquiry, ValidationErrors } from '../types';
import {
  validateCustomKitInquiry,
  formatWhatsAppInquiryMessage,
  createWhatsAppUrl,
  WHATSAPP_PHONE_NUMBER
} from '../utils/inquiry';

export const CustomKitForm: React.FC = () => {
  const [formData, setFormData] = useState<CustomKitInquiry>({
    sport: 'Football',
    orderType: 'Team',
    customerName: '',
    contactNumber: '',
    teamName: '',
    quantity: 12,
    preferredColors: 'Royal Blue & Midnight Charcoal',
    playerNamesAndNumbers: '',
    sizesBreakdown: 'S: 2, M: 5, L: 4, XL: 1',
    requestedDate: '',
    additionalNotes: '',
    referenceImageName: ''
  });

  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [copied, setCopied] = useState(false);
  const [submissionFeedback, setSubmissionFeedback] = useState<string | null>(null);

  // Real-time generated WhatsApp text
  const currentWhatsAppMessage = formatWhatsAppInquiryMessage(formData);
  const currentWhatsAppUrl = createWhatsAppUrl(WHATSAPP_PHONE_NUMBER, currentWhatsAppMessage);

  const handleInputChange = (field: keyof CustomKitInquiry, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field as keyof ValidationErrors]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Image file size should be under 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
        handleInputChange('referenceImageName', file.name);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    handleInputChange('referenceImageName', '');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateCustomKitInquiry(formData);

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmissionFeedback('Please review and correct the highlighted fields before sending.');
      return;
    }

    setErrors({});
    setSubmissionFeedback(
      'Inquiry details compiled! Opening WhatsApp to send your pre-order details directly to S NAIMAT SPORTS.'
    );

    // Open WhatsApp URL directly
    window.open(currentWhatsAppUrl, '_blank', 'noopener,noreferrer');
  };

  const handleCopyMessage = async () => {
    try {
      await navigator.clipboard.writeText(currentWhatsAppMessage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <section id="custom-kits" className="py-20 bg-[#0B0D10] border-t border-[#151A21]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#C6F235] mb-2">
            <span>CUSTOM TEAMWEAR INQUIRY BUILDER</span>
          </div>
          <h2 className="font-display text-3xl sm:text-5xl font-black text-white tracking-tight mb-4">
            PRE-ORDER CUSTOM KITS
          </h2>
          <p className="text-sm sm:text-base text-[#A6AFBD] leading-relaxed">
            Create custom football or cricket kits for your team, club, or tournament squad. Fill out your specifications below to generate a pre-order inquiry for direct WhatsApp consultation with S NAIMAT SPORTS in Quetta.
          </p>

          {/* Non-deceptive honest pre-order notice */}
          <div className="mt-4 flex items-start gap-2.5 p-3.5 bg-[#151A21] border border-[#232C3A] rounded-lg text-xs text-[#A6AFBD]">
            <Info className="w-4 h-4 text-[#1769FF] shrink-0 mt-0.5" />
            <div>
              <strong className="text-white">Pre-Order Inquiry Notice:</strong> This form compiles an inquiry summary. It is not an automated charged checkout. Exact pricing, fabric swatches, sizing confirmation, and production timelines are finalized directly via WhatsApp or in-store at Gurdat Singh Rd, Quetta.
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Main Form (7 cols on desktop) */}
          <form
            onSubmit={handleSubmit}
            noValidate
            className="lg:col-span-7 bg-[#12161D] border border-[#1E2633] rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl"
          >
            {/* Sport & Order Type Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Sport Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-white mb-2">
                  Select Sport <span className="text-[#1769FF]">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Football', 'Cricket'] as const).map((sport) => {
                    const isSelected = formData.sport === sport;
                    return (
                      <button
                        type="button"
                        key={sport}
                        onClick={() => handleInputChange('sport', sport)}
                        className={`py-2.5 px-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all border ${
                          isSelected
                            ? 'bg-[#1769FF] border-[#1769FF] text-white shadow-sm'
                            : 'bg-[#151A21] border-[#222B38] text-[#A6AFBD] hover:text-white hover:bg-[#1A222D]'
                        }`}
                      >
                        {sport}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Order Type */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-white mb-2">
                  Order Type <span className="text-[#1769FF]">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {(['Individual', 'Team'] as const).map((type) => {
                    const isSelected = formData.orderType === type;
                    return (
                      <button
                        type="button"
                        key={type}
                        onClick={() => {
                          handleInputChange('orderType', type);
                          if (type === 'Team' && formData.quantity < 5) {
                            handleInputChange('quantity', 12);
                          } else if (type === 'Individual' && formData.quantity > 4) {
                            handleInputChange('quantity', 1);
                          }
                        }}
                        className={`py-2.5 px-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all border ${
                          isSelected
                            ? 'bg-[#1769FF] border-[#1769FF] text-white shadow-sm'
                            : 'bg-[#151A21] border-[#222B38] text-[#A6AFBD] hover:text-white hover:bg-[#1A222D]'
                        }`}
                      >
                        {type}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Customer Details Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Customer Name */}
              <div>
                <label htmlFor="customerName" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                  Your Full Name <span className="text-red-400">*</span>
                </label>
                <input
                  id="customerName"
                  type="text"
                  placeholder="e.g. Tariq Mehmood"
                  value={formData.customerName}
                  onChange={(e) => handleInputChange('customerName', e.target.value)}
                  className={`w-full bg-[#151A21] border rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:ring-1 ${
                    errors.customerName
                      ? 'border-red-500 focus:ring-red-500'
                      : 'border-[#242D3B] focus:border-[#1769FF] focus:ring-[#1769FF]'
                  }`}
                />
                {errors.customerName && (
                  <p className="mt-1 text-[11px] text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.customerName}
                  </p>
                )}
              </div>

              {/* Contact Number */}
              <div>
                <label htmlFor="contactNumber" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                  Contact / WhatsApp Number <span className="text-red-400">*</span>
                </label>
                <input
                  id="contactNumber"
                  type="tel"
                  placeholder="e.g. 0313 1234567"
                  value={formData.contactNumber}
                  onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                  className={`w-full bg-[#151A21] border rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:ring-1 ${
                    errors.contactNumber
                      ? 'border-red-500 focus:ring-red-500'
                      : 'border-[#242D3B] focus:border-[#1769FF] focus:ring-[#1769FF]'
                  }`}
                />
                {errors.contactNumber && (
                  <p className="mt-1 text-[11px] text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.contactNumber}
                  </p>
                )}
              </div>
            </div>

            {/* Team Name & Quantity Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Optional Team Name */}
              <div>
                <label htmlFor="teamName" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                  Team / Club Name <span className="text-[#8E9AA8] font-normal lowercase">(optional)</span>
                </label>
                <input
                  id="teamName"
                  type="text"
                  placeholder="e.g. Quetta Bolan FC or City Tigers"
                  value={formData.teamName}
                  onChange={(e) => handleInputChange('teamName', e.target.value)}
                  className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
                />
              </div>

              {/* Quantity */}
              <div>
                <label htmlFor="quantity" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                  Estimated Quantity <span className="text-red-400">*</span>
                </label>
                <div className="flex items-center gap-2">
                  <input
                    id="quantity"
                    type="number"
                    min="1"
                    max="500"
                    value={formData.quantity}
                    onChange={(e) => handleInputChange('quantity', parseInt(e.target.value) || 1)}
                    className={`w-full bg-[#151A21] border rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:ring-1 ${
                      errors.quantity
                        ? 'border-red-500 focus:ring-red-500'
                        : 'border-[#242D3B] focus:border-[#1769FF] focus:ring-[#1769FF]'
                    }`}
                  />
                  <span className="text-xs text-[#8E9AA8] whitespace-nowrap">
                    {formData.orderType === 'Team' ? 'kits (min 5)' : 'kit'}
                  </span>
                </div>
                {errors.quantity && (
                  <p className="mt-1 text-[11px] text-red-400 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" /> {errors.quantity}
                  </p>
                )}
              </div>
            </div>

            {/* Preferred Colors */}
            <div>
              <label htmlFor="preferredColors" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                Preferred Kit Colors <span className="text-red-400">*</span>
              </label>
              <input
                id="preferredColors"
                type="text"
                placeholder="e.g. Dark Charcoal base with Electric Blue sleeves and Neon Lime trim"
                value={formData.preferredColors}
                onChange={(e) => handleInputChange('preferredColors', e.target.value)}
                className={`w-full bg-[#151A21] border rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:ring-1 ${
                  errors.preferredColors
                    ? 'border-red-500 focus:ring-red-500'
                    : 'border-[#242D3B] focus:border-[#1769FF] focus:ring-[#1769FF]'
                }`}
              />
              {errors.preferredColors && (
                <p className="mt-1 text-[11px] text-red-400 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> {errors.preferredColors}
                </p>
              )}
            </div>

            {/* Sizes / Sizing Breakdown */}
            <div>
              <label htmlFor="sizesBreakdown" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                Sizes Breakdown
              </label>
              <input
                id="sizesBreakdown"
                type="text"
                placeholder="e.g. S: 2, M: 6, L: 4, XL: 2 or specify Youth/Adult sizes"
                value={formData.sizesBreakdown}
                onChange={(e) => handleInputChange('sizesBreakdown', e.target.value)}
                className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
              />
              <p className="mt-1 text-[11px] text-[#717F91]">
                Available adult sizes: S, M, L, XL, XXL. We can also provide tailored youth sizes upon inquiry.
              </p>
            </div>

            {/* Player Names & Numbers */}
            <div>
              <label htmlFor="playerNamesAndNumbers" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                Player Names &amp; Numbers <span className="text-[#8E9AA8] font-normal lowercase">(if known)</span>
              </label>
              <textarea
                id="playerNamesAndNumbers"
                rows={3}
                placeholder="e.g. 1. Ali (GK), 7. Rashid, 9. Bilal (C), 10. Hamza..."
                value={formData.playerNamesAndNumbers}
                onChange={(e) => handleInputChange('playerNamesAndNumbers', e.target.value)}
                className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
              />
            </div>

            {/* Requested Date & Additional Notes Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="requestedDate" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                  Requested Target Date <span className="text-[#8E9AA8] font-normal lowercase">(optional)</span>
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-[#8E9AA8] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    id="requestedDate"
                    type="date"
                    value={formData.requestedDate}
                    onChange={(e) => handleInputChange('requestedDate', e.target.value)}
                    className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg pl-9 pr-3 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
                  />
                </div>
              </div>

              {/* Reference Artwork Upload */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                  Reference Logo / Design <span className="text-[#8E9AA8] font-normal lowercase">(optional)</span>
                </label>
                {imagePreview ? (
                  <div className="flex items-center gap-3 p-2 bg-[#151A21] border border-[#242D3B] rounded-lg">
                    <img
                      src={imagePreview}
                      alt="Uploaded reference logo preview"
                      className="w-10 h-10 object-cover rounded"
                    />
                    <div className="flex-1 min-w-0 text-xs">
                      <p className="text-white truncate font-medium">{formData.referenceImageName}</p>
                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        className="text-[11px] text-red-400 hover:underline"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 p-2.5 bg-[#151A21] border border-dashed border-[#2E394A] hover:border-[#1769FF] rounded-lg cursor-pointer transition-colors text-xs text-[#A6AFBD]">
                    <Upload className="w-4 h-4 text-[#1769FF]" />
                    <span>Upload Logo / Reference</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
            </div>

            {/* Additional Notes */}
            <div>
              <label htmlFor="additionalNotes" className="block text-xs font-bold uppercase tracking-wider text-white mb-1.5">
                Additional Notes or Special Instructions
              </label>
              <textarea
                id="additionalNotes"
                rows={2}
                placeholder="Mention specific collar preferences, sponsor placement, fabric weight, or tournament regulations..."
                value={formData.additionalNotes}
                onChange={(e) => handleInputChange('additionalNotes', e.target.value)}
                className="w-full bg-[#151A21] border border-[#242D3B] rounded-lg px-3.5 py-2.5 text-xs text-white placeholder-[#717F91] focus:outline-none focus:border-[#1769FF]"
              />
            </div>

            {/* Submission feedback */}
            {submissionFeedback && (
              <div className="p-3 bg-[#151A21] border border-[#232C3A] rounded-lg text-xs text-[#C6F235] flex items-center gap-2">
                <Sparkles className="w-4 h-4 shrink-0" />
                <span>{submissionFeedback}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              <button
                type="submit"
                className="flex-1 py-3.5 px-6 bg-[#C6F235] hover:bg-[#b5e028] active:scale-[0.99] text-[#0B0D10] text-xs font-black uppercase tracking-wider rounded-lg transition-all shadow-md flex items-center justify-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6F235]"
              >
                <Send className="w-4 h-4" />
                <span>Send WhatsApp Inquiry</span>
              </button>

              <button
                type="button"
                onClick={handleCopyMessage}
                className="py-3.5 px-5 bg-[#151A21] hover:bg-[#1C2430] border border-[#2B3545] text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-all flex items-center justify-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-[#C6F235]" />
                    <span className="text-[#C6F235]">Copied to Clipboard!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-[#8E9AA8]" />
                    <span>Copy Inquiry Text</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Right Column: Live WhatsApp Message Preview (5 cols on desktop) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-[#12161D] border border-[#1E2633] rounded-2xl p-6 sm:p-7 sticky top-28 shadow-xl">
              <div className="flex items-center justify-between pb-4 border-b border-[#1E2633] mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#25D366]/10 border border-[#25D366]/30 flex items-center justify-center text-[#25D366]">
                    <Shirt className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-display text-sm font-bold text-white">
                      WhatsApp Message Preview
                    </h3>
                    <div className="text-[10px] text-[#717F91]">
                      Real-time formatted inquiry summary
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCopyMessage}
                  className="text-xs text-[#C6F235] hover:underline flex items-center gap-1 font-medium"
                >
                  {copied ? 'Copied!' : 'Copy'}
                </button>
              </div>

              {/* Message Box Styled like WhatsApp bubble */}
              <div className="p-4 bg-[#0B0E12] rounded-xl border border-[#1D2531] font-mono text-xs leading-relaxed text-[#CFD8E3] whitespace-pre-wrap select-all max-h-[360px] overflow-y-auto">
                {currentWhatsAppMessage}
              </div>

              {/* Quick direct WhatsApp link */}
              <div className="mt-5 pt-4 border-t border-[#1E2633] space-y-3">
                <a
                  href={currentWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 bg-[#1769FF] hover:bg-[#0f54d1] text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 text-center"
                >
                  <Send className="w-3.5 h-3.5 text-[#C6F235]" />
                  <span>Open WhatsApp Directly</span>
                </a>

                <div className="text-center text-[11px] text-[#717F91]">
                  Direct WhatsApp: <strong className="text-white">+92 313 8873304</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
