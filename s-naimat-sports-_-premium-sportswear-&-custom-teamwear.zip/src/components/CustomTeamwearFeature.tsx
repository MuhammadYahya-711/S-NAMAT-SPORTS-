import React from 'react';
import { Shirt, Award, Palette, Hash, Users, ArrowRight } from 'lucide-react';
import { CUSTOM_IMAGE } from '../data/products';

interface CustomTeamwearFeatureProps {
  onCustomKitClick: () => void;
}

export const CustomTeamwearFeature: React.FC<CustomTeamwearFeatureProps> = ({ onCustomKitClick }) => {
  const customFeatures = [
    {
      icon: Palette,
      title: 'Custom Club Colors & Patterns',
      description: 'Choose your signature club palette, gradient sleeves, geometric textures, and collar styles.'
    },
    {
      icon: Award,
      title: 'Emblems & Sponsor Branding',
      description: 'High-definition crest printing, tournament chest sponsor artwork, and custom sleeve patches.'
    },
    {
      icon: Hash,
      title: 'Player Names & Squad Numbers',
      description: 'Crisp, permanent dye-sublimated numbering and back names that will not peel or crack.'
    },
    {
      icon: Users,
      title: 'Squad Sizing (Individual to 100+)',
      description: 'Flexible sizing breakdown from Youth to XXL for both cricket elevens and football squads.'
    }
  ];

  return (
    <section className="py-20 bg-[#0E1217] border-t border-[#18202A] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Feature Highlights */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-[#C6F235]">
              <span>BESPOKE TEAMWEAR PRE-ORDERS</span>
            </div>

            <h2 className="font-display text-3xl sm:text-5xl font-black text-white tracking-tight leading-[1.1]">
              WEAR YOUR IDENTITY.<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-[#1769FF]">
                CUSTOM FOOTBALL &amp; CRICKET KITS.
              </span>
            </h2>

            <p className="text-sm sm:text-base text-[#A6AFBD] leading-relaxed">
              Equip your school, club, or tournament team with tailored athletic apparel. S NAIMAT SPORTS handles customized football and cricket kit pre-orders from our showroom on Gurdat Singh Road, Quetta.
            </p>

            {/* Feature Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              {customFeatures.map((feat) => {
                const Icon = feat.icon;
                return (
                  <div
                    key={feat.title}
                    className="p-4 rounded-xl bg-[#151A21] border border-[#222B38] space-y-2"
                  >
                    <div className="w-8 h-8 rounded-lg bg-[#1769FF]/10 border border-[#1769FF]/30 flex items-center justify-center text-[#1769FF]">
                      <Icon className="w-4 h-4 text-[#C6F235]" />
                    </div>
                    <h3 className="font-display text-sm font-bold text-white">
                      {feat.title}
                    </h3>
                    <p className="text-xs text-[#8E9AA8] leading-relaxed">
                      {feat.description}
                    </p>
                  </div>
                );
              })}
            </div>

            {/* CTA Button */}
            <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={onCustomKitClick}
                className="px-6 py-3.5 bg-[#1769FF] hover:bg-[#0f54d1] active:scale-[0.98] text-white text-xs font-bold uppercase tracking-wider rounded transition-all shadow-md flex items-center justify-center gap-2 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
              >
                <span>Pre-Order Custom Teamwear</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              <div className="text-xs text-[#8E9AA8] flex items-center justify-center sm:justify-start gap-1.5">
                <Shirt className="w-4 h-4 text-[#C6F235]" />
                <span>Football &amp; Cricket available</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Showcase Card */}
          <div className="lg:col-span-6">
            <div className="relative rounded-2xl overflow-hidden bg-[#151A21] border border-[#222B38] shadow-2xl">
              <div className="aspect-[4/3] relative bg-[#0E1217]">
                <img
                  src={CUSTOM_IMAGE}
                  alt="Custom athletic sports team jerseys displayed in showroom"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    if (target.src !== '/images/custom.jpg') {
                      target.src = '/images/custom.jpg';
                    }
                  }}
                  className="w-full h-full object-cover object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0B0D10] via-transparent to-transparent opacity-80" />
              </div>

              {/* Informational overlay box */}
              <div className="p-6 bg-[#151A21] border-t border-[#222B38]">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-[#C6F235]">
                      Pre-Order Inquiry Process
                    </span>
                    <h4 className="font-display text-base font-bold text-white">
                      How Custom Teamwear Orders Work
                    </h4>
                  </div>
                  <span className="px-2.5 py-1 text-[10px] font-semibold rounded bg-[#0B0D10] text-[#A6AFBD] border border-[#2A3442]">
                    WhatsApp Powered
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs text-[#A6AFBD]">
                  <div className="p-2 rounded bg-[#0E1217] border border-[#1E2633]">
                    <div className="font-bold text-white text-xs mb-0.5">1. Inquire</div>
                    <div className="text-[10px] text-[#717F91]">Fill kit details &amp; colors</div>
                  </div>
                  <div className="p-2 rounded bg-[#0E1217] border border-[#1E2633]">
                    <div className="font-bold text-white text-xs mb-0.5">2. WhatsApp</div>
                    <div className="text-[10px] text-[#717F91]">Discuss mockups &amp; sizes</div>
                  </div>
                  <div className="p-2 rounded bg-[#0E1217] border border-[#1E2633]">
                    <div className="font-bold text-white text-xs mb-0.5">3. Production</div>
                    <div className="text-[10px] text-[#717F91]">Finalize and collect</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
