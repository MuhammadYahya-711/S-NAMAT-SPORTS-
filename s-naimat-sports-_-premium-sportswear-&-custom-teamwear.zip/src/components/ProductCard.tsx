import React from 'react';
import { Eye, MessageSquare } from 'lucide-react';
import { Product } from '../types';
import { WHATSAPP_PHONE_NUMBER, createWhatsAppUrl, formatProductWhatsAppInquiry } from '../utils/inquiry';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView }) => {
  const whatsAppInquiryUrl = createWhatsAppUrl(
    WHATSAPP_PHONE_NUMBER,
    formatProductWhatsAppInquiry(product)
  );

  return (
    <div className="group bg-[#151A21] rounded-xl border border-[#1E2633] hover:border-[#2D394C] transition-all duration-300 flex flex-col overflow-hidden">
      {/* Product Image Area */}
      <div className="relative aspect-[4/3] bg-[#0E1217] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            const fallback = `/images/${product.category}.jpg`;
            if (target.src !== fallback) {
              target.src = fallback;
            }
          }}
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
        />

        {/* Sample Catalog Tag (Mandatory per prompt) */}
        {product.isSample && (
          <div className="absolute top-3 left-3 z-10">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#A6AFBD] bg-[#0B0D10]/90 backdrop-blur-sm px-2 py-0.5 rounded border border-[#252E3B]">
              Sample Showcase
            </span>
          </div>
        )}

        {/* Quick View Overlay Button */}
        <div className="absolute inset-0 bg-[#0B0D10]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center p-4">
          <button
            onClick={() => onQuickView(product)}
            className="px-4 py-2 bg-white text-[#0B0D10] text-xs font-bold uppercase tracking-wider rounded flex items-center gap-1.5 shadow-lg hover:bg-[#C6F235] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#C6F235]"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Quick View</span>
          </button>
        </div>
      </div>

      {/* Product Details */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Unboxed Metadata (Zero-pill discipline) */}
          <div className="flex items-center gap-2 text-xs text-[#8E9AA8] mb-1.5 font-medium">
            <span>{product.categoryLabel}</span>
            <span aria-hidden="true" className="text-[#323D4E]">·</span>
            <span className="text-[#1769FF]">{product.recommendedSport}</span>
            <span aria-hidden="true" className="text-[#323D4E]">·</span>
            <span>{product.fitType}</span>
          </div>

          <h3 className="font-display text-base font-bold text-white group-hover:text-[#1769FF] transition-colors line-clamp-1 mb-2">
            {product.name}
          </h3>

          <p className="text-xs text-[#A6AFBD] line-clamp-2 leading-relaxed mb-4">
            {product.description}
          </p>

          {/* Size labels */}
          <div className="flex items-center gap-1.5 mb-4 text-[11px] text-[#8E9AA8]">
            <span className="text-[#5D6B7D]">Sizes:</span>
            {product.availableSizes.map((size) => (
              <span key={size} className="px-1.5 py-0.5 rounded bg-[#10141A] border border-[#222B38] text-white">
                {size}
              </span>
            ))}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="pt-3 border-t border-[#1F2733] flex items-center justify-between gap-2">
          <div className="text-xs text-[#A6AFBD]">
            <span className="text-white font-semibold">Pre-Order / Inquire</span>
            <div className="text-[10px] text-[#717F91]">WhatsApp Quote</div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => onQuickView(product)}
              className="p-2 text-[#A6AFBD] hover:text-white bg-[#10141A] hover:bg-[#1C232E] border border-[#222B38] rounded transition-colors"
              title="View product details"
              aria-label={`View details for ${product.name}`}
            >
              <Eye className="w-3.5 h-3.5" />
            </button>
            <a
              href={whatsAppInquiryUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-2 bg-[#1769FF] hover:bg-[#0f54d1] text-white text-xs font-semibold rounded flex items-center gap-1.5 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
            >
              <MessageSquare className="w-3.5 h-3.5 text-[#C6F235]" />
              <span>Inquire</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
