import React, { useState, useEffect } from 'react';
import { X, MessageSquare, Check, ShieldCheck, Shirt, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { WHATSAPP_PHONE_NUMBER, createWhatsAppUrl, formatProductWhatsAppInquiry } from '../utils/inquiry';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onCustomizeSimilar: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onCustomizeSimilar,
}) => {
  const [selectedSize, setSelectedSize] = useState<string>('L');

  useEffect(() => {
    if (product && product.availableSizes.length > 0) {
      setSelectedSize(product.availableSizes[0]);
    }
  }, [product]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!product) return null;

  const inquiryUrl = createWhatsAppUrl(
    WHATSAPP_PHONE_NUMBER,
    formatProductWhatsAppInquiry(product, selectedSize)
  );

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-product-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-[#0B0D10]/80 backdrop-blur-sm animate-in fade-in duration-200"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-3xl bg-[#12161D] border border-[#222B38] rounded-2xl shadow-2xl overflow-hidden my-8"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close product view"
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-[#151A21]/80 hover:bg-[#1E2530] text-[#A6AFBD] hover:text-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1769FF]"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left: Product Image */}
          <div className="relative aspect-[4/3] md:aspect-auto md:h-full bg-[#0B0D10] overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              referrerPolicy="no-referrer"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                const fallback = `/images/${product.category}.jpg`;
                if (target.src !== fallback) {
                  target.src = fallback;
                }
              }}
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute top-4 left-4 z-10">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#C6F235] bg-[#0B0D10]/85 backdrop-blur-sm px-2.5 py-1 rounded border border-[#252E3B]">
                Sample Catalog Model
              </span>
            </div>
          </div>

          {/* Right: Details & WhatsApp Action */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div>
              {/* Unboxed Metadata */}
              <div className="flex items-center gap-2 text-xs text-[#8E9AA8] mb-2 font-medium">
                <span>{product.categoryLabel}</span>
                <span aria-hidden="true" className="text-[#323D4E]">·</span>
                <span className="text-[#1769FF]">{product.recommendedSport}</span>
                <span aria-hidden="true" className="text-[#323D4E]">·</span>
                <span>{product.fitType}</span>
              </div>

              <h2
                id="modal-product-title"
                className="font-display text-xl sm:text-2xl font-bold text-white mb-3"
              >
                {product.name}
              </h2>

              <p className="text-xs sm:text-sm text-[#A6AFBD] leading-relaxed mb-5">
                {product.description}
              </p>

              {/* Technical features list */}
              <div className="space-y-2 mb-6">
                <div className="text-[11px] font-bold uppercase tracking-wider text-[#717F91]">
                  Technical Construction &amp; Fit
                </div>
                {product.features.map((feature) => (
                  <div key={feature} className="flex items-start gap-2 text-xs text-[#CFD8E3]">
                    <Check className="w-3.5 h-3.5 text-[#C6F235] shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              {/* Size Selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-white mb-2">
                  Select Size to Inquire: <span className="text-[#C6F235] font-mono">{selectedSize}</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {product.availableSizes.map((size) => {
                    const isSelected = selectedSize === size;
                    return (
                      <button
                        type="button"
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`w-10 h-10 rounded-lg text-xs font-bold uppercase transition-all flex items-center justify-center border ${
                          isSelected
                            ? 'bg-[#1769FF] text-white border-[#1769FF] shadow-sm'
                            : 'bg-[#151A21] text-[#A6AFBD] border-[#252E3B] hover:text-white hover:border-[#384659]'
                        }`}
                      >
                        {size}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Inquiry Notice and Action */}
            <div className="pt-4 border-t border-[#1E2633] space-y-3">
              <div className="flex items-start gap-2 text-[11px] text-[#8E9AA8]">
                <AlertCircle className="w-3.5 h-3.5 text-[#1769FF] shrink-0 mt-0.5" />
                <span>
                  S NAIMAT SPORTS offers direct in-store inquiries in Quetta. Pre-order quotes and stock confirmation are provided via WhatsApp.
                </span>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <a
                  href={inquiryUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 px-4 bg-[#1769FF] hover:bg-[#0f54d1] text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <MessageSquare className="w-4 h-4 text-[#C6F235]" />
                  <span>Inquire in Size {selectedSize}</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onCustomizeSimilar();
                  }}
                  className="py-3 px-4 bg-[#151A21] hover:bg-[#1E2530] border border-[#2B3545] text-white text-xs font-bold uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <Shirt className="w-4 h-4 text-[#C6F235]" />
                  <span>Customize For Team</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
