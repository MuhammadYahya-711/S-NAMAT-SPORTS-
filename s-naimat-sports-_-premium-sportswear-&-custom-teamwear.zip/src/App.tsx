import { useState, useEffect } from 'react';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategoryShowcase } from './components/CategoryShowcase';
import { FeaturedCollection } from './components/FeaturedCollection';
import { CustomTeamwearFeature } from './components/CustomTeamwearFeature';
import { CustomKitForm } from './components/CustomKitForm';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { FAQSection } from './components/FAQSection';
import { Footer } from './components/Footer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { SAMPLE_PRODUCTS } from './data/products';
import { CategoryType, Product } from './types';
import { MessageSquare } from 'lucide-react';
import { WHATSAPP_PHONE_NUMBER } from './utils/inquiry';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [modalProduct, setModalProduct] = useState<Product | null>(null);

  // Synchronize hash / tab changes smoothly
  const handleNavigate = (tab: string) => {
    setActiveTab(tab);

    if (tab === 'home') {
      setSelectedCategory('all');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (tab === 'shop') {
      setSelectedCategory('all');
      const el = document.getElementById('collection');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
      else window.scrollTo({ top: 500, behavior: 'smooth' });
    } else if (tab === 'football') {
      setSelectedCategory('football');
      const el = document.getElementById('collection');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'cricket') {
      setSelectedCategory('cricket');
      const el = document.getElementById('collection');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'tracksuits') {
      setSelectedCategory('tracksuits');
      const el = document.getElementById('collection');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'custom') {
      setSelectedCategory('custom');
      const el = document.getElementById('custom-kits');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'about') {
      const el = document.getElementById('about');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'contact') {
      const el = document.getElementById('contact');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCustomKitClick = () => {
    setActiveTab('custom');
    const el = document.getElementById('custom-kits');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleShopClick = () => {
    setActiveTab('shop');
    const el = document.getElementById('collection');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSelectCategoryFromShowcase = (categoryId: string) => {
    if (categoryId === 'custom') {
      handleCustomKitClick();
    } else {
      setSelectedCategory(categoryId as CategoryType);
      setActiveTab(categoryId);
      const el = document.getElementById('collection');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Listen to hash if user navigates with back button or direct link
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (hash) {
        handleNavigate(hash);
      }
    };
    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  return (
    <div className="min-h-screen bg-[#0B0D10] text-white flex flex-col selection:bg-[#1769FF] selection:text-white">
      {/* 1. Announcement Bar */}
      <AnnouncementBar onCustomKitClick={handleCustomKitClick} />

      {/* 2. Top Bar Navigation Contract */}
      <Header
        activeTab={activeTab}
        onNavigate={handleNavigate}
        onCustomKitClick={handleCustomKitClick}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* 3. Hero Section */}
        <Hero
          onShopClick={handleShopClick}
          onCustomKitClick={handleCustomKitClick}
        />

        {/* 4. Category Showcase: 4 attractive image cards */}
        <CategoryShowcase onSelectCategory={handleSelectCategoryFromShowcase} />

        {/* 5. Featured Collection: Professional product cards */}
        <FeaturedCollection
          products={SAMPLE_PRODUCTS}
          selectedCategory={selectedCategory}
          onCategoryChange={(cat) => {
            setSelectedCategory(cat);
            if (cat === 'all') setActiveTab('shop');
            else setActiveTab(cat);
          }}
          onQuickView={(p) => setModalProduct(p)}
          onCustomKitClick={handleCustomKitClick}
        />

        {/* 6. Custom Teamwear Feature Section */}
        <CustomTeamwearFeature onCustomKitClick={handleCustomKitClick} />

        {/* 7. Dedicated Custom Kit Pre-Order Inquiry Form */}
        <CustomKitForm />

        {/* 8. About S NAIMAT SPORTS Section */}
        <AboutSection />

        {/* 9. Contact CTA & Store Location */}
        <ContactSection />

        {/* 10. Frequently Asked Questions Section */}
        <FAQSection />
      </main>

      {/* 11. Footer */}
      <Footer
        onNavigate={handleNavigate}
        onCustomKitClick={handleCustomKitClick}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={modalProduct}
        onClose={() => setModalProduct(null)}
        onCustomizeSimilar={() => {
          setModalProduct(null);
          handleCustomKitClick();
        }}
      />

      {/* Quick Floating WhatsApp Inquire Button for Instant Mobile Access */}
      <aside aria-label="Quick contact" className="fixed bottom-6 right-6 z-40">
        <a
          href={`https://wa.me/${WHATSAPP_PHONE_NUMBER}?text=${encodeURIComponent('Hello S NAIMAT SPORTS! I would like to inquire about sportswear products.')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center gap-2 px-4 py-3 bg-[#25D366] hover:bg-[#20ba5a] text-[#0B0D10] font-bold text-xs uppercase tracking-wider rounded-full shadow-2xl transition-all duration-200 hover:scale-105 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
          aria-label="Direct WhatsApp inquiry with S NAIMAT SPORTS"
        >
          <MessageSquare className="w-5 h-5 text-[#0B0D10] fill-current" />
          <span className="hidden sm:inline">WhatsApp Inquiries</span>
        </a>
      </aside>
    </div>
  );
}
