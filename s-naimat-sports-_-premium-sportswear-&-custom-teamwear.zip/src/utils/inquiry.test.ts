import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateCustomKitInquiry,
  formatWhatsAppInquiryMessage,
  createWhatsAppUrl,
  formatProductWhatsAppInquiry,
  WHATSAPP_PHONE_NUMBER
} from './inquiry';
import { CustomKitInquiry, Product } from '../types';

test('validates incomplete custom kit inquiry', () => {
  const errors = validateCustomKitInquiry({});
  assert.ok(errors.customerName);
  assert.ok(errors.contactNumber);
  assert.ok(errors.quantity);
  assert.ok(errors.preferredColors);
});

test('validates team order minimum quantity constraint', () => {
  const errors = validateCustomKitInquiry({
    customerName: 'Muhammad Ali',
    contactNumber: '03131234567',
    sport: 'Football',
    orderType: 'Team',
    quantity: 3,
    preferredColors: 'Blue/White'
  });
  assert.ok(errors.quantity);
  assert.match(errors.quantity, /minimum of 5/i);
});

test('passes validation for valid custom kit inquiry', () => {
  const validData: CustomKitInquiry = {
    sport: 'Cricket',
    orderType: 'Team',
    customerName: 'Zubair Khan',
    contactNumber: '03138873304',
    teamName: 'Quetta Strikers',
    quantity: 15,
    preferredColors: 'Midnight Charcoal & Athletic Lime',
    playerNamesAndNumbers: '1. Zubair (C), 7. Tariq, 10. Bilal',
    sizesBreakdown: '5 Medium, 7 Large, 3 XL',
    requestedDate: '2026-11-15',
    additionalNotes: 'Sublimated club logo on front chest'
  };

  const errors = validateCustomKitInquiry(validData);
  assert.equal(Object.keys(errors).length, 0);

  const message = formatWhatsAppInquiryMessage(validData);
  assert.ok(message.includes('S NAIMAT SPORTS - Custom Kit Pre-Order Inquiry'));
  assert.ok(message.includes('Quetta Strikers'));
  assert.ok(message.includes('Zubair Khan'));
  assert.ok(message.includes('Pre-Order Inquiry'));

  const url = createWhatsAppUrl(WHATSAPP_PHONE_NUMBER, message);
  assert.ok(url.startsWith('https://wa.me/923138873304?text='));
  assert.ok(url.includes(encodeURIComponent('Quetta Strikers')));
});

test('formats product inquiry message correctly', () => {
  const product: Product = {
    id: 'fb-01',
    name: 'Velocity Pro Match Jersey',
    category: 'football',
    categoryLabel: 'Football Kits',
    description: 'Performance match kit',
    features: ['Quick-dry', 'Breathable weave'],
    image: '/test.jpg',
    isSample: true,
    availableSizes: ['S', 'M', 'L', 'XL'],
    recommendedSport: 'Football',
    fitType: 'Athletic Fit'
  };

  const msg = formatProductWhatsAppInquiry(product, 'L');
  assert.ok(msg.includes('Velocity Pro Match Jersey'));
  assert.ok(msg.includes('Requested Size:'));
  assert.ok(msg.includes('L'));
  assert.ok(msg.includes('S NAIMAT SPORTS - Product Inquiry'));
});
