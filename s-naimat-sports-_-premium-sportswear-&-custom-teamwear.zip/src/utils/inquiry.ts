import { CustomKitInquiry, Product, ValidationErrors } from '../types';

export const WHATSAPP_PHONE_NUMBER = '923138873304';
export const DISPLAY_PHONE = '03138873304';
export const DISPLAY_ADDRESS = '52Q7+CC9, Gurdat Singh Rd, Quetta, Pakistan';
export const MAPS_URL = 'https://www.google.com/maps/search/?api=1&query=52Q7%2BCC9%2C%20Gurdat%20Singh%20Rd%2C%20Quetta%2C%20Pakistan';

/**
 * Validates a custom kit pre-order inquiry
 */
export function validateCustomKitInquiry(data: Partial<CustomKitInquiry>): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!data.customerName || data.customerName.trim().length === 0) {
    errors.customerName = 'Please enter your name.';
  } else if (data.customerName.trim().length < 2) {
    errors.customerName = 'Name must be at least 2 characters.';
  }

  if (!data.contactNumber || data.contactNumber.trim().length === 0) {
    errors.contactNumber = 'Please enter your contact phone or WhatsApp number.';
  } else {
    const cleanPhone = data.contactNumber.replace(/[\s\-\+\(\)]/g, '');
    if (cleanPhone.length < 8) {
      errors.contactNumber = 'Please enter a valid phone number (at least 8 digits).';
    }
  }

  const quantity = Number(data.quantity);
  if (isNaN(quantity) || quantity <= 0) {
    errors.quantity = 'Quantity must be at least 1 item.';
  } else if (data.orderType === 'Team' && quantity < 5) {
    errors.quantity = 'Team orders generally require a minimum of 5 kits.';
  }

  if (!data.preferredColors || data.preferredColors.trim().length === 0) {
    errors.preferredColors = 'Please specify your preferred team/kit colors.';
  }

  return errors;
}

/**
 * Formats a custom kit pre-order inquiry into a clean, readable text message
 */
export function formatWhatsAppInquiryMessage(data: CustomKitInquiry): string {
  const lines: string[] = [
    '🏆 *S NAIMAT SPORTS - Custom Kit Pre-Order Inquiry*',
    '----------------------------------------',
    `*Sport:* ${data.sport}`,
    `*Order Type:* ${data.orderType}`,
    `*Customer Name:* ${data.customerName.trim()}`,
    `*Contact Number:* ${data.contactNumber.trim()}`,
  ];

  if (data.teamName && data.teamName.trim().length > 0) {
    lines.push(`*Team Name:* ${data.teamName.trim()}`);
  }

  lines.push(`*Estimated Quantity:* ${data.quantity}`);
  lines.push(`*Preferred Colors:* ${data.preferredColors.trim()}`);

  if (data.sizesBreakdown && data.sizesBreakdown.trim().length > 0) {
    lines.push(`*Size Breakdown:* ${data.sizesBreakdown.trim()}`);
  }

  if (data.playerNamesAndNumbers && data.playerNamesAndNumbers.trim().length > 0) {
    lines.push(`*Player Names & Numbers:* ${data.playerNamesAndNumbers.trim()}`);
  }

  if (data.requestedDate && data.requestedDate.trim().length > 0) {
    lines.push(`*Requested Target Date:* ${data.requestedDate.trim()}`);
  }

  if (data.additionalNotes && data.additionalNotes.trim().length > 0) {
    lines.push(`*Additional Requirements:* ${data.additionalNotes.trim()}`);
  }

  if (data.referenceImageName) {
    lines.push(`*Reference Artwork Attached:* Yes (${data.referenceImageName}) - ready to send over WhatsApp`);
  }

  lines.push('----------------------------------------');
  lines.push('ℹ️ *Note:* This is a pre-order inquiry. Looking forward to discussing design details, fabric samples, and quote.');

  return lines.join('\n');
}

/**
 * Generates the direct WhatsApp URL
 */
export function createWhatsAppUrl(phoneNumber: string, message: string): string {
  const cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
  return `https://wa.me/${cleanNumber}?text=${encodeURIComponent(message)}`;
}

/**
 * Formats product inquiry message
 */
export function formatProductWhatsAppInquiry(product: Product, selectedSize?: string): string {
  const sizeText = selectedSize ? ` in size ${selectedSize}` : '';
  const lines: string[] = [
    '⚽ *S NAIMAT SPORTS - Product Inquiry*',
    '----------------------------------------',
    `*Product:* ${product.name}`,
    `*Category:* ${product.categoryLabel}`,
    `*Sport:* ${product.recommendedSport}`,
  ];

  if (sizeText) {
    lines.push(`*Requested Size:* ${selectedSize}`);
  }

  lines.push('----------------------------------------');
  lines.push('Hello! I am inquiring about availability, pricing, and ordering details for this item at your Quetta store.');

  return lines.join('\n');
}
