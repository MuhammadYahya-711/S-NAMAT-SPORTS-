import { Product } from '../types';
import heroImage from '../assets/images/hero_sportswear_athlete_1793288306273.jpg';
import footballImage from '../assets/images/category_football_kit_1793288307128.jpg';
import cricketImage from '../assets/images/category_cricket_kit_1793288306817.jpg';
import tracksuitImage from '../assets/images/category_tracksuit_1793288307019.jpg';
import customImage from '../assets/images/category_custom_teamwear_1793288307397.jpg';

export const HERO_IMAGE = heroImage || '/images/hero.jpg';
export const FOOTBALL_IMAGE = footballImage || '/images/football.jpg';
export const CRICKET_IMAGE = cricketImage || '/images/cricket.jpg';
export const TRACKSUIT_IMAGE = tracksuitImage || '/images/tracksuit.jpg';
export const CUSTOM_IMAGE = customImage || '/images/custom.jpg';

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 'sn-fb-01',
    name: 'Velocity Match Football Shirt',
    category: 'football',
    categoryLabel: 'Football Kits',
    description: 'Engineered performance football shirt featuring athletic electric-blue contouring, lightweight breathable mesh weave, and moisture-wicking technology for high-intensity matches.',
    features: [
      'Moisture-dispersing technical weave',
      'Athletic ergonomic seam placement',
      'Reinforced collar ribbing',
      'Pre-order customization ready (crest, sponsor, numbers)'
    ],
    image: FOOTBALL_IMAGE,
    isSample: true,
    availableSizes: ['S', 'M', 'L', 'XL', 'XXL'],
    recommendedSport: 'Football',
    fitType: 'Athletic Fit'
  },
  {
    id: 'sn-cr-01',
    name: 'AeroFlow Cricket Match Kit',
    category: 'cricket',
    categoryLabel: 'Cricket Kits',
    description: 'High-comfort cricket match and training jersey with contrast athletic lime piping, strategic underarm ventilation zones, and flexible range-of-motion construction.',
    features: [
      'High-ventilation aeroflow panels',
      'UV & heat dispersion fabrication',
      'Comfort-stretch rib crewneck',
      'Available for full squad pre-order sizing'
    ],
    image: CRICKET_IMAGE,
    isSample: true,
    availableSizes: ['S', 'M', 'L', 'XL', 'XXL'],
    recommendedSport: 'Cricket',
    fitType: 'Regular Fit'
  },
  {
    id: 'sn-tr-01',
    name: 'Stealth Pro Athletic Tracksuit',
    category: 'tracksuits',
    categoryLabel: 'Tracksuits',
    description: 'Precision-cut two-piece athletic tracksuit engineered with midnight black and cool gray panelling, full-zip technical jacket, and tapered training joggers.',
    features: [
      'Double-knit thermal regulation polyester',
      'Zipped utility pockets on jacket and trousers',
      'Tapered athletic ankle cuffs with zip expansion',
      'Clean minimalist athletic silhouette'
    ],
    image: TRACKSUIT_IMAGE,
    isSample: true,
    availableSizes: ['M', 'L', 'XL', 'XXL'],
    recommendedSport: 'Training / Fitness',
    fitType: 'Athletic Fit'
  },
  {
    id: 'sn-tm-01',
    name: 'Bespoke Sublimated Football Team Kit',
    category: 'custom',
    categoryLabel: 'Custom Kits',
    description: 'Fully customized sublimation football kits built to your club specification. Choose your colors, club badge, sponsor lettering, and individual player numbers.',
    features: [
      'Zero-bleed full dye sublimation printing',
      'Custom team badges, club logos & typography',
      'Individual player names & back numbers included',
      'Pre-order inquiry with direct WhatsApp quote'
    ],
    image: CUSTOM_IMAGE,
    isSample: true,
    availableSizes: ['S', 'M', 'L', 'XL', 'XXL'],
    recommendedSport: 'Football',
    fitType: 'Athletic Fit'
  },
  {
    id: 'sn-tm-02',
    name: 'Bespoke Sublimated Cricket Teamwear',
    category: 'custom',
    categoryLabel: 'Custom Kits',
    description: 'Custom team cricket jerseys, trousers, and training tops tailored for clubs and tournament teams. High-durability fabric with crisp bespoke branding.',
    features: [
      'Sublimated sponsor artwork & team emblems',
      'Tournament-spec breathable sports mesh',
      'Custom colorway matching your team palette',
      'Squad number and name allocations'
    ],
    image: CRICKET_IMAGE,
    isSample: true,
    availableSizes: ['S', 'M', 'L', 'XL', 'XXL'],
    recommendedSport: 'Cricket',
    fitType: 'Regular Fit'
  },
  {
    id: 'sn-fb-02',
    name: 'Pro Training Football Shirt & Shorts',
    category: 'football',
    categoryLabel: 'Football Kits',
    description: 'All-weather training kit set designed for football academies, club practices, and competitive training sessions.',
    features: [
      'Reinforced side seam stitching',
      'Anti-chafing flatlock seams',
      'Elastic waistband with internal drawstring',
      'Available for individual and bulk team inquiries'
    ],
    image: FOOTBALL_IMAGE,
    isSample: true,
    availableSizes: ['S', 'M', 'L', 'XL'],
    recommendedSport: 'Football',
    fitType: 'Athletic Fit'
  }
];

export const CATEGORIES = [
  {
    id: 'football',
    title: 'Football Kits',
    tagline: 'Match shirts, academy sets, and football apparel',
    image: FOOTBALL_IMAGE,
    badgeText: 'Match & Training'
  },
  {
    id: 'cricket',
    title: 'Cricket Kits',
    tagline: 'Tournament jerseys, match trousers, and cricket gear',
    image: CRICKET_IMAGE,
    badgeText: 'Tournament Grade'
  },
  {
    id: 'tracksuits',
    title: 'Tracksuits',
    tagline: 'High-performance warm-up and athletic travel suits',
    image: TRACKSUIT_IMAGE,
    badgeText: 'Warm-Up & Street'
  },
  {
    id: 'custom',
    title: 'Custom Kits',
    tagline: 'Bespoke teamwear for football & cricket clubs',
    image: CUSTOM_IMAGE,
    badgeText: 'Pre-Order Inquiry'
  }
];
